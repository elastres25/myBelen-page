# Blackbaud Upcoming Assignments Feed

This mini-site turns a private Blackbaud iCal feed into a polished, student-facing assignment list while keeping the private feed URL out of the public HTML.

## Files
- `index.html` — student-facing assignment cards with expandable details.
- `assignments.json` — sanitized assignment data generated automatically.
- `scripts/update_assignments.py` — converts the Blackbaud iCal feed to JSON.
- `.github/workflows/update-assignments.yml` — refreshes the feed once per hour.

## Install in your existing GitHub Pages repository

1. Copy all four items above into the root of your `myBelen-page` repository, preserving the folders.
2. In GitHub, open **Settings → Secrets and variables → Actions → New repository secret**.
3. Name the secret exactly: `BLACKBAUD_ICAL_URL`
4. Paste the full `webcal://...` Blackbaud feed URL as the secret value.
5. Open **Actions → Update Blackbaud assignments → Run workflow** once to create the first real `assignments.json`.
6. Wait for GitHub Pages to redeploy.

## URLs to embed

All assignments:
`https://elastres25.github.io/myBelen-page/?limit=6`

Theology 6 only:
`https://elastres25.github.io/myBelen-page/?course=Theology%206&limit=6`

Theology 7 only:
`https://elastres25.github.io/myBelen-page/?course=Theology%207&limit=6`

If you do not want this to replace your current home page, put these files in a subfolder such as `assignments/`. Then the embed URL becomes:
`https://elastres25.github.io/myBelen-page/assignments/?course=Theology%206&limit=6`

## Recommended Blackbaud iframe

```html
<iframe
  src="https://elastres25.github.io/myBelen-page/assignments/?course=Theology%206&limit=6"
  width="100%"
  height="620"
  frameborder="0"
  style="border:0;width:100%;"
></iframe>
```

## Important
Do **not** paste the private Blackbaud iCal URL into `index.html`, `assignments.json`, or any public GitHub file. Keep it only in the GitHub Actions secret.

## What students see
Each assignment shows its date, title, course, due-date status, and expandable details. If Blackbaud includes a direct `URL` in the iCal event, the card automatically displays an **Open in Blackbaud** button. If the feed does not provide a URL, the button is simply omitted.
